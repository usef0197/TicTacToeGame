package com.example.tictactoe

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.*

class SettingsActivity : AppCompatActivity() {

    var b: Button? = null
    var g1: RadioGroup? = null
    var g2: RadioGroup? = null
    var rd: RadioButton? = null
    var p1: String? = null
    var p2: String? = null
    var e1: EditText? = null
    var e2: EditText? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)

        b = findViewById<View>(R.id.save) as Button
        g1 = findViewById<View>(R.id.player1) as RadioGroup
        g2 = findViewById<View>(R.id.player2) as RadioGroup

        e1 = findViewById<View>(R.id.e1) as EditText;
        e2 = findViewById<View>(R.id.e2) as EditText;


        b!!.setOnClickListener {
            var sel = g1!!.checkedRadioButtonId
            rd = findViewById<View>(sel) as RadioButton
            p1 = rd!!.text.toString()
            sel = g2!!.checkedRadioButtonId
            rd = findViewById<View>(sel) as RadioButton
            p2 = rd!!.text.toString()

            if (p1.equals(p2, ignoreCase = true)) {
                Toast.makeText(this, "Both players cannot choose same symbol", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            var name1 = e1!!.text.toString();
            if (name1.isEmpty()) {
                name1 = "Player 1";
            }
            var name2 = e2!!.text.toString();
            if (name2.isEmpty()) {
                name2 = "Player 2";
            }

            val i = Intent(this, Game::class.java)
            i.putExtra("Player1", p1)
            i.putExtra("Player2", p2)
            i.putExtra("name1", name1)
            i.putExtra("name2", name2)

            startActivity(i)
            finish()
        }
    }}
