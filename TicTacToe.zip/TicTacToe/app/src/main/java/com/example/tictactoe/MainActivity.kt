package com.example.tictactoe

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.Button
import android.widget.RadioButton
import android.widget.RadioGroup
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.activity_main.*


class MainActivity : AppCompatActivity() {
    var b: Button? = null
    var g1: RadioGroup? = null
    var g2: RadioGroup? = null
    var rd: RadioButton? = null
    var p1: String? = null
    var p2: String? = null
    var click: Button? = null
    val context: Context = this
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        click = findViewById<View>(R.id.clickHere) as Button
        click!!.setOnClickListener {
            setContentView(R.layout.menu)
            b = findViewById<View>(R.id.play) as Button
            g1 = findViewById<View>(R.id.player1) as RadioGroup
            g2 = findViewById<View>(R.id.player2) as RadioGroup
            b!!.setOnClickListener {
                var sel = g1!!.checkedRadioButtonId
                rd = findViewById<View>(sel) as RadioButton
                p1 = rd!!.text.toString()
                sel = g2!!.checkedRadioButtonId
                rd = findViewById<View>(sel) as RadioButton
                p2 = rd!!.text.toString()
                val i = Intent(context, Game::class.java)
                i.putExtra("Player1", p1)
                i.putExtra("Player2", p2)
                startActivity(i)
            }
        }
    }
        override fun onCreateOptionsMenu(menu: Menu?): Boolean {
            menuInflater.inflate(R.menu.menu, menu)
            return true
        }

        override fun onOptionsItemSelected(item: MenuItem): Boolean {
            when (item?.itemId) {
                R.id.help -> {
                    var intent = Intent(this, HelpActivity::class.java)
                    startActivity(intent)
                    return super.onOptionsItemSelected(item)
                }
                R.id.settings -> {
                    var intent = Intent(this, SettingsActivity::class.java)
                    startActivity(intent)
                    return super.onOptionsItemSelected(item)
                }
                else -> return super.onOptionsItemSelected(item)
    }}}







