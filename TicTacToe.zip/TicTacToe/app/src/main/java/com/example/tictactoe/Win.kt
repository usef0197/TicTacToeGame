package com.example.tictactoe

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity


class Win : AppCompatActivity() {
    var winn: TextView? = null
    var b: Button? = null
    val context: Context = this
    var im: ImageView? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.win_layout)
        val intent = intent
        val win = intent.getStringExtra("winner")
        winn = findViewById<View>(R.id.wintxt) as TextView
        b = findViewById<View>(R.id.back) as Button
        im = findViewById<View>(R.id.trophy) as ImageView
        im!!.setImageResource(R.drawable.trophy)
        winn!!.text = win
        b!!.setOnClickListener {
            val i = Intent(context, MainActivity::class.java)
            startActivity(i)
        }
    }
}
