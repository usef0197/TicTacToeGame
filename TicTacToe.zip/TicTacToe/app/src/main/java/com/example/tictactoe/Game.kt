package com.example.tictactoe

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.*
import android.widget.AdapterView.OnItemClickListener
import androidx.appcompat.app.AppCompatActivity


class Game : AppCompatActivity() {
    var p1: String? = null
    var p2: String? = null
    var j = 0
    var gridview: GridView? = null
    var visitedp1 = intArrayOf(-1, -1, -1, -1, -1, -1, -1, -1, -1)
    var visitedp2 = intArrayOf(-1, -1, -1, -1, -1, -1, -1, -1, -1)
    val context: Context = this
    fun check(visitedp1: IntArray, visitedp2: IntArray) {
        var flag = 0
        var winner: String? = null

        if (visitedp1[0] == 1 && visitedp1[4] == 1 && visitedp1[8] == 1) {
            flag = 1
            winner = "Player 1"
        } else if (visitedp1[2] == 1 && visitedp1[4] == 1 && visitedp1[6] == 1) {
            flag = 1
            winner = "Player 1"
        } else if (visitedp1[0] == 1 && visitedp1[3] == 1 && visitedp1[6] == 1) {
            flag = 1
            winner = "Player 1"
        } else if (visitedp1[1] == 1 && visitedp1[4] == 1 && visitedp1[7] == 1) {
            flag = 1
            winner = "Player 1"
        } else if (visitedp1[2] == 1 && visitedp1[5] == 1 && visitedp1[8] == 1) {
            flag = 1
            winner = "Player 1"
        } else if (visitedp1[0] == 1 && visitedp1[1] == 1 && visitedp1[2] == 1) {
            flag = 1
            winner = "Player 1"
        } else if (visitedp1[3] == 1 && visitedp1[4] == 1 && visitedp1[5] == 1) {
            flag = 1
            winner = "Player 1"
        } else if (visitedp1[6] == 1 && visitedp1[7] == 1 && visitedp1[8] == 1) {
            flag = 1
            winner = "Player 1"
        }

        if (visitedp2[0] == 1 && visitedp2[4] == 1 && visitedp2[8] == 1) {
            flag = 1
            winner = "Player 2"
        } else if (visitedp2[2] == 1 && visitedp2[4] == 1 && visitedp2[6] == 1) {
            flag = 1
            winner = "Player 2"
        } else if (visitedp2[0] == 1 && visitedp2[3] == 1 && visitedp2[6] == 1) {
            flag = 1
            winner = "Player 2"
        } else if (visitedp2[1] == 1 && visitedp2[4] == 1 && visitedp2[7] == 1) {
            flag = 1
            winner = "Player 2"
        } else if (visitedp2[2] == 1 && visitedp2[5] == 1 && visitedp2[8] == 1) {
            flag = 1
            winner = "Player 2"
        } else if (visitedp2[0] == 1 && visitedp2[1] == 1 && visitedp2[2] == 1) {
            flag = 1
            winner = "Player 2"
        } else if (visitedp2[3] == 1 && visitedp2[4] == 1 && visitedp2[5] == 1) {
            flag = 1
            winner = "Player 2"
        } else if (visitedp2[6] == 1 && visitedp2[7] == 1 && visitedp2[8] == 1) {
            flag = 1
            winner = "Player 2"
        }
        if (flag == 1) {
            val i = Intent(context, Win::class.java)
            i.putExtra("winner", winner)
            startActivity(i)
        }
        if (i == 8) {
            val gamedraw = Intent(context, DrawGame::class.java)
            startActivity(gamedraw)
        }
    }

    var t: TextView? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        for (k in 0..8) {
            visitedp1[k] = -1
            visitedp2[k] = -1
        }
        i = 0
        super.onCreate(savedInstanceState)
        setContentView(R.layout.game_layout)
        val intent = intent
        p1 = intent.getStringExtra("Player1")
        p2 = intent.getStringExtra("Player2")
        if (p1.equals(p2, ignoreCase = true)) {
            Toast.makeText(context, "Both players cannot choose same symbol", 2000).show()
            finish()
        } else {
            gridview = findViewById<View>(R.id.gridview1) as GridView
            val adapter = ArrayAdapter(this, R.layout.game_layout2, symbols)
            gridview!!.adapter = adapter
            gridview!!.onItemClickListener =
                OnItemClickListener { parent, view, position, id ->
                    var flag = 0
                    t = view.findViewById<View>(R.id.txt) as TextView
                    j = 0
                    while (j < 9) {
                        if (visitedp1[position] == 1 || visitedp2[position] == 1) {
                            flag = 1
                            Toast.makeText(context, "Invalid....", 200).show()
                            break
                        }
                        ++j
                    }
                    if (flag == 0) {
                        if (i % 2 == 0) {
                            t!!.text = p1
                            visitedp1[position] = 1
                        } else {
                            t!!.text = p2
                            visitedp2[position] = 1
                        }
                        check(visitedp1, visitedp2)
                        i = i + 1
                    }
                }
        }
    }

    companion object {
        var i = 0
        val symbols = arrayOf("", "", "", "", "", "", "", "", "")
    }
    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item?.itemId) {
            R.id.help -> {
                var intent = Intent(this, HelpActivity::class.java)
                startActivity(intent)
                return super.onOptionsItemSelected(item)
            }
            R.id.settings -> {
                var intent = Intent(this, SettingsActivity::class.java)
                startActivity(intent)
                return super.onOptionsItemSelected(item)
            }
            else -> return super.onOptionsItemSelected(item)
}}}
